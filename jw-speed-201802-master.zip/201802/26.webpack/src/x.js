import React, { Component } from 'react'
import { render } from 'react-dom'
render(<h1>hello zfpx</h1>, window.app);

console.log('ok')