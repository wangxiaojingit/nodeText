module.exports = 'hello123';

import 'bootstrap';