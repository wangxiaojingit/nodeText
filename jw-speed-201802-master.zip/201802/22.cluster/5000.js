let http = require('http');
http.createServer(function(req,res){
    res.end('zf1')
}).listen(5000);