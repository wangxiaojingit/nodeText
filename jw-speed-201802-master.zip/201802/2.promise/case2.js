let Promise = require('./Promise');
let promise = new Promise(function (resolve, reject) {
    resolve(1000);
});



