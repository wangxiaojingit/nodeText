process.on('message',function(msg){
    console.log(msg)
})